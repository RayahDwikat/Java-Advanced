import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

    private Client() {}

    public static void main(String[] args) {

        String host = (args.length < 1) ? null : args[0];
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 2001);
            arraysInterface stub = (arraysInterface) registry.lookup("arraysServer");
		int a[] = {2,3,-1,3, 5, 10, 12, -4, 20};
		int b[] = {3,-1,-4,2, 10, 2, 12, 9, 7};
		
		System.out.println("Maximum number in a:" + stub.max(a));
		System.out.println("Maximum number in b:" + stub.max(b));
		System.out.println("Minimum number in a:" + stub.min(a));
		System.out.println("Minimum number in b:" + stub.min(b));
		
		int c[] = stub.add(a, b);
		for(int i=0; i<a.length; i++)
			System.out.print(a[i] + "  ");
		System.out.println();
		for(int i=0; i<b.length; i++)
			System.out.print(b[i] + "  ");
		System.out.println();
		for(int i=0; i<c.length; i++)
			System.out.print(c[i] + "  ");
		System.out.println();
		
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
