import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Server implements arraysInterface {

    public Server() {}

    public int max(int a[]){
		int maxNumber = a[0];
		for(int i=0;i<a.length;i++)
			if(a[i]>maxNumber) maxNumber=a[i];
		return maxNumber;
	}

	public int min(int a[]){
		int minNumber = a[0];
		for(int i=0;i<a.length;i++)
			if(a[i]<minNumber) minNumber=a[i];
		return minNumber;
	}
	
	public int [] add(int a[], int b[]){
		int c[] = new int[a.length];
		for(int i=0;i<a.length;i++)
			c[i] = a[i] + b[i];
		return c;
	}

    public static void main(String args[]) {

        try {
            Server obj = new Server();
            arraysInterface stub = (arraysInterface) UnicastRemoteObject.exportObject(obj, 0);

            // Bind the remote object's stub in the registry
            Registry registry = LocateRegistry.getRegistry(2001);
            registry.bind("arraysServer", stub);

            System.err.println("Arrays Server is ready");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
