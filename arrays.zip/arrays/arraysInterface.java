import java.rmi.Remote;
import java.rmi.RemoteException;


public interface arraysInterface extends Remote {
    int max(int a[]) throws RemoteException;
    int min(int a[]) throws RemoteException;
    int [] add(int a[], int b[]) throws RemoteException;
}


